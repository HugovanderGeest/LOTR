# Start document

## bij de training Bootstrap

#### dit document bevat de inhoud van de training: De teksten van een pagina over LOTR: Lord of the Rings.

Het resultaat zie je op: https://youtu.be/9s0KxNCn04Q

Presentatie: https://blanken5.home.xs4all.nl/webSlidesPresentaties/bootstrapPresentatie.html#slide=1

Instructie: https://blanken5.home.xs4all.nl/bootstrap.html
